<?php
$actual_link = site_url(uri_string());
$actual_link = $_SERVER['QUERY_STRING'] ? $actual_link.'?'.$_SERVER['QUERY_STRING'] : $actual_link;
$actual_link = urlencode($actual_link);
?>
<!-- end:: Header -->
<div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor">


    <!-- begin:: Subheader -->
    <div class="kt-subheader kt-grid__item" id="kt_subheader">
        <div class="kt-subheader__main">
            <h3 class="kt-subheader__title"><?php echo $page_sub_name; ?></h3>
        </div>
    </div>
    <!-- end:: Subheader -->


    <!-- begin:: Content -->
    <div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">
        <div class="row">

            <?php
            $this->load->view('flash_notif_view');
            ?>

            <div class="col-xl-12">
			
				<?php
                $attributes = array('autocomplete'=>"off");
                echo form_open($form_action, $attributes);
                ?>
                <!-- START PORTLET -->
                <div class="kt-portlet">
                    <div class="kt-portlet__head">
                        <div class="kt-portlet__head-label">
                            <h3 class="kt-portlet__head-title">
                                Pencarian
                            </h3>
                        </div>
                    </div>

                    <div class="kt-portlet__body">
					
                        <div class="col-12">
							<label>Kelompok Tahun Evaluasi</label>
							<select class="form-control kt-input" name="tahun_evaluasi">
								<option value="0"></option>
								<?php
								foreach($rowT as $key => $val) {
									$seld = ($request['tahun_evaluasi']==$val['tahun_evaluasi'])? 'selected' : '';
									echo '<option value="'.$val['tahun_evaluasi'].'" '.$seld.'>'.$val['tahun_evaluasi'].'</option>';
								}
								?>
							</select>
						</div>

                    </div>

                    <div class="kt-portlet__foot">
                        <div class="kt-form__actions kt-form__actions--solid">
                            <div class="row">
                                <div class="col-lg-12">
                                    <button type="submit" class="btn btn-success pl-5 pr-5">Lihat Data</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END PORTLET -->

                <?php echo form_close(); ?>


                <!--begin::Portlet-->
                <div class="kt-portlet">
                    <div class="kt-portlet__body">
						
						<!--begin: Datatable -->
                        <div class="table-responsive">
                            <?php
							$juml = count($row);
							$css = '';
							if($juml<=0) {
								echo 'data tidak ditemukan';
							} else {
							?>
							
							<div class="alert alert-outline-info fade show" role="alert">
								<div class="alert-text">
									URL untuk memantau seluruh progress peserta:<br/>
									<?=$url_progress?>
								</div>
							</div>
							
							<div class="text-center mb-4">
								<a id="btRekap" class="btn btn-success" href="<?=site_url('classroom/evaluasi_lv3_do_rekap/th/'.$request['tahun_evaluasi'])?>">Rekap All</a>
								<a class="btn btn-success" href="<?=site_url('classroom/evaluasi_lv3_do_export/th/'.$request['tahun_evaluasi'])?>">Export All</a>
							</div>
							
							<table class="table">
								<tr>
									<td style="width:1%">No</td>
									<td style="width:1%">ID</td>
									<td>Nama</td>
									<td style="width:1%">&nbsp;</td>
									<td style="width:1%">&nbsp;</td>
								</tr>
								
								<?php
								$i = 0;
								foreach($row as $key => $val) {
									$i++;
									
									if($val['status']=="0") $val['cr_name'] .= '&nbsp;<span class="text-danger">(non-active)</span>';
								?>
								
								<tr>
									<td><?=$i?></td>
									<td><?=$val['cr_id']?></td>
									<td><?=$val['cr_name']?></td>
									<td><a href="<?=site_url('classroom/evaluasi_lv3/'.$val['cr_id'])?>" target="_blank">update_data</a></td>
									<td><a href="<?=site_url('classroom/evaluasi_lv3_sync_atasan_aghris/'.$val['cr_id'])?>" target="_blank">sync_aghris</a></td>
								</tr>
								
								<?php } ?>
							</table>
							
							<?php
							}
							?>
                        </div>
                        <!--end: Datatable -->
                    </div>
                    <!--end::Form-->
                </div>
                <!--end::Portlet-->
            </div>

        </div>
    </div>
    <!-- end:: Content -->


</div>

<script type="text/javascript">
    $(document).ready(function() {
        $("#btRekap").click(function(){
			var flag = confirm('Anda yakin ingin melakukan rekap? Proses mungkin akan memakan waktu yg lama.');
			if(flag==false) {
				return ;
			}
			$('#dform').submit();
		});

    });
</script>


